# FieldQR 采集器 (Android Kotlin 离线版)

野外高对比度离线二维码与高精度GPS定位点位采集系统。

---

## 🌟 核心功能与技术规范
1. **纯本地离线运行**：无需任何网络服务器或外部后端，数据完全保存在设备本地 Room 数据库中，断电或重启数据永久持久化。
2. **ZXing 连续扫码**：集成 `com.journeyapps:zxing-android-embedded`，支持相机取景与实时连续识别。识别到二维码后立即调用 `barcodeView.pause()` 暂停相机，待用户确认或取消后再 `resume()` 恢复。
3. **强制高精度 GPS 定位**：
   - 使用 `FusedLocationProvider` 搭配 `PRIORITY_HIGH_ACCURACY`，并提供原生 `LocationManager.GPS_PROVIDER` 双重保障。
   - 彻底禁用网络基站粗略定位，获取真实纬度、经度、海拔与 UTC 时间。
   - GPS 搜星看板：界面实时显示搜星状态、定位精度（米数）。若未锁定卫星，禁止保存记录并弹窗引导到开阔室外。
4. **Room 数据库与防重复机制**：
   - 字段包括：`id`(自增), `qrText`(二维码内容), `lat`(纬度), `lon`(经度), `altitude`(海拔), `recordTime`(记录时间)。
   - 扫码识别后弹出确认对话框：【保存】/【放弃】。
   - 插入前校验 `countByQrText(qrText)`，相同二维码自动拦截防重复。
5. **Excel 友好 CSV 导出**：
   - 一键将采集记录导出到手机公共存储 `Download` 文件夹。
   - 表头为：`记录时间,二维码内容,纬度,经度,海拔`。
   - 写入 **UTF-8 BOM**（`0xEF, 0xBB, 0xBF`），解决 Windows/Mac 版 Excel 打开中文乱码问题。
6. **野外强光 UI**：
   - 纯黑高对比度暗黑界面（`#0B0F17`），辅以高饱和荧光绿与警戒橙黄，强光下字迹清晰可读。

---

## 📁 完整工程目录结构

```text
FieldQR-Collector/
├── build.gradle.kts                      // 根工程构建脚本
├── settings.gradle.kts                   // 模块与仓库设置
├── gradle.properties                     // JVM 与 AndroidX 配置
├── README.md                             // 工程说明与编译手册
└── app/
    ├── build.gradle.kts                  // 模块构建配置 (Room/ZXing/FusedLocation)
    └── src/main/
        ├── AndroidManifest.xml           // 权限声明与入口配置
        ├── res/
        │   ├── values/
        │   │   ├── colors.xml            // 野外高对比度色彩
        │   │   ├── strings.xml           // 字符资源
        │   │   └── themes.xml            // 无Actionbar深色主题
        │   ├── layout/
        │   │   ├── activity_main.xml     // 主页面框架 (双Tab+Fragment)
        │   │   ├── fragment_scan.xml     // 扫码取景与GPS看板
        │   │   ├── fragment_records.xml  // 记录列表与导出
        │   │   ├── item_record.xml       // 单条点位列表卡片
        │   │   └── dialog_qr_confirm.xml // 点位保存确认弹窗
        │   └── menu/
        │       └── bottom_nav_menu.xml   // 底部导航菜单
        └── java/com/fieldqr/collector/
            ├── data/
            │   ├── QrRecord.kt           // Room 实体类
            │   ├── QrRecordDao.kt        // Room DAO
            │   └── AppDatabase.kt        // Room 数据库单例
            ├── location/
            │   └── GpsLocationHelper.kt  // 强制GPS高精度定位管理类
            ├── export/
            │   └── CsvExporter.kt        // CSV带BOM导出工具类
            └── ui/
                ├── MainActivity.kt       // 主入口与动态权限
                ├── ScanFragment.kt       // 扫码采集 Fragment
                ├── RecordListFragment.kt // 记录列表 Fragment
                └── RecordAdapter.kt      // RecyclerView 适配器
```

---

## 🛠️ 如何下载源码与编译生成 APK

### 步骤 1：下载源码
点击本页面顶部的 **【一键下载完整 Android 源码 ZIP】** 按钮，解压得到完整的 `FieldQR-Collector` 文件夹。

### 步骤 2：导入 Android Studio
1. 打开 **Android Studio** (推荐 Hedgehog 2023.1.1 或更高版本，内置 JDK 17+)。
2. 选择 **Open**，选择刚才解压出来的 `FieldQR-Collector` 根目录。
3. 等待 Gradle 自动完成依赖下载与 Sync 同步。

### 步骤 3：连接真机开启离线野外测试
1. 使用 USB 线连接 Android 手机，并开启【开发者选项】中的【USB 调试】。
2. 在 Android Studio 顶部设备选择栏中选择您的手机设备。
3. 点击绿色三角形运行按钮 **Run 'app'**（快捷键 `Shift + F10`）。

### 步骤 4：编译生成独立 APK 文件
- **方式 A (Android Studio 菜单)：**
  点击顶部菜单栏：`Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`。构建完成后右下角会弹出提示，点击 `locate` 即可找到生成的 `app-debug.apk`。
- **方式 B (命令行终端)：**
  在工程根目录下执行终端命令：
  ```bash
  # Linux / macOS
  ./gradlew assembleDebug

  # Windows
  gradlew.bat assembleDebug
  ```
  生成的 APK 路径为：`app/build/outputs/apk/debug/app-debug.apk`。将此 APK 安装至任意 Android 8.0 (SDK 26) 以上手机即可完全离线独立运行！
