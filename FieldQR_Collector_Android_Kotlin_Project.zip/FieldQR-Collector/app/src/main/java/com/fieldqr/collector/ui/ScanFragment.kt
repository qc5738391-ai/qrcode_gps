package com.fieldqr.collector.ui

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.fieldqr.collector.R
import com.fieldqr.collector.data.AppDatabase
import com.fieldqr.collector.data.QrRecord
import com.fieldqr.collector.databinding.DialogQrConfirmBinding
import com.fieldqr.collector.databinding.FragmentScanBinding
import com.fieldqr.collector.location.GpsLocationHelper
import com.google.zxing.BarcodeFormat
import com.google.zxing.ResultPoint
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DefaultDecoderFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 扫码采集 Fragment
 * 核心逻辑：
 * 1. ZXing 连续识别二维码
 * 2. 识别到后立即 pause() 暂停相机预览
 * 3. 检查 GPS 是否锁定：若未锁定，弹出搜星警告并禁止保存；
 * 4. 检查防重复逻辑：若数据库已存在相同 qrText，拦截提示；
 * 5. 用户确认【保存】或【放弃】后，再 resume() 恢复扫码。
 */
class ScanFragment : Fragment() {

    private var _binding: FragmentScanBinding? = null
    private val binding get() = _binding!!

    private lateinit var gpsHelper: GpsLocationHelper
    private val db by lazy { AppDatabase.getDatabase(requireContext()) }

    // 防抖与弹窗状态控制
    private var isDialogShowing = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initGps()
        initScanner()
    }

    private fun initGps() {
        gpsHelper = GpsLocationHelper(requireContext(), object : GpsLocationHelper.GpsStateListener {
            override fun onGpsStatusChanged(isLocked: Boolean, accuracy: Float, statusDesc: String) {
                if (!isAdded) return
                binding.tvGpsStatus.text = statusDesc
                if (isLocked) {
                    binding.tvGpsStatus.setTextColor(Color.parseColor("#00E676"))
                    binding.dotGpsStatus.setBackgroundColor(Color.parseColor("#00E676"))
                    binding.tvOutdoorPrompt.visibility = View.GONE
                    binding.tvAccuracy.text = "精度: ±${"%.1f".format(accuracy)}m (优)"
                } else {
                    binding.tvGpsStatus.setTextColor(Color.parseColor("#FFB300"))
                    binding.dotGpsStatus.setBackgroundColor(Color.parseColor("#FFB300"))
                    binding.tvOutdoorPrompt.visibility = View.VISIBLE
                    binding.tvAccuracy.text = if (accuracy > 0) "精度: ±${"%.1f".format(accuracy)}m" else "精度: 搜星中"
                }
            }

            override fun onLocationUpdated(location: android.location.Location, utcTimeString: String) {
                if (!isAdded) return
                binding.tvLatLon.text = "纬度: ${"%.6f".format(location.latitude)}  经度: ${"%.6f".format(location.longitude)}"
                binding.tvAltitude.text = "海拔: ${"%.1f".format(location.altitude)} m"
            }
        })
    }

    private fun initScanner() {
        // 限制仅识别 QR_CODE，提升野外识别速度与抗反光能力
        binding.barcodeView.decoderFactory = DefaultDecoderFactory(listOf(BarcodeFormat.QR_CODE))

        binding.barcodeView.decodeContinuous(object : BarcodeCallback {
            override fun barcodeResult(result: BarcodeResult?) {
                val text = result?.text ?: return
                if (isDialogShowing) return

                // 核心修复要求2：识别到二维码后立即暂停相机预览，防止连续弹窗
                binding.barcodeView.pause()
                handleQrDetected(text)
            }

            override fun possibleResultPoints(resultPoints: MutableList<ResultPoint>?) {}
        })
    }

    private fun handleQrDetected(qrText: String) {
        val location = gpsHelper.currentLocation
        val isGpsLocked = gpsHelper.isGpsLocked

        // 核心修复要求1：GPS未锁定或精度不足时，禁止保存记录，弹窗提示等待搜星
        if (!isGpsLocked || location == null) {
            AlertDialog.Builder(requireContext())
                .setTitle("⚠️ GPS定位未锁定")
                // 【修复点】：使用 \n 替代真实的换行，修复编译报错
                .setMessage("当前GPS定位尚未锁定高精度卫星定位信号！\n\n为了保障野外采集点位质量，未锁星时禁止保存记录。\n请到开阔室外等待搜星成功后再试。")
                .setPositiveButton("确定") { dialog, _ ->
                    dialog.dismiss()
                    resumeScanner()
                }
                .setCancelable(false)
                .show()
            return
        }

        // 异步检查 Room 数据库是否存在相同 qrText (防重复录入)
        lifecycleScope.launch {
            val exists = withContext(Dispatchers.IO) {
                db.qrRecordDao().countByQrText(qrText) > 0
            }

            if (exists) {
                AlertDialog.Builder(requireContext())
                    .setTitle("⚠️ 重复点位提示")
                    // 【修复点】：使用 \n 替代真实的换行，修复编译报错
                    .setMessage("检测到该二维码已在数据库中存在：\n${qrText}\n防重复规则生效，已自动拦截。")
                    .setPositiveButton("我知道了") { dialog, _ ->
                        dialog.dismiss()
                        resumeScanner()
                    }
                    .setCancelable(false)
                    .show()
                return@launch
            }

            // 二维码有效且GPS锁定，弹出【保存】 / 【放弃】确认对话框
            showConfirmDialog(qrText, location)
        }
    }

    private fun showConfirmDialog(qrText: String, location: android.location.Location) {
        isDialogShowing = true
        val dialogBinding = DialogQrConfirmBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        val utcTime = gpsHelper.getFormattedUtcTime()
        dialogBinding.tvDialogQrText.text = qrText
        dialogBinding.tvDialogGpsInfo.text = "纬度: ${"%.6f".format(location.latitude)}\n经度: ${"%.6f".format(location.longitude)}\n海拔: ${"%.1f".format(location.altitude)} m\n时间: $utcTime\n精度: ±${"%.1f".format(location.accuracy)} m"

        // 点击【放弃】
        dialogBinding.btnDialogDiscard.setOnClickListener {
            dialog.dismiss()
            isDialogShowing = false
            resumeScanner()
        }

        // 点击【保存】
        dialogBinding.btnDialogSave.setOnClickListener {
            lifecycleScope.launch {
                val record = QrRecord(
                    qrText = qrText,
                    lat = location.latitude,
                    lon = location.longitude,
                    altitude = location.altitude,
                    recordTime = utcTime
                )
                withContext(Dispatchers.IO) {
                    db.qrRecordDao().insert(record)
                }
                Toast.makeText(requireContext(), "✅ 点位已保存入库", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                isDialogShowing = false
                resumeScanner()
            }
        }

        dialog.show()
    }

    private fun resumeScanner() {
        if (_binding != null) {
            binding.barcodeView.resume()
        }
    }

    override fun onResume() {
        super.onResume()
        binding.barcodeView.resume()
        gpsHelper.startLocationUpdates()
    }

    override fun onPause() {
        super.onPause()
        binding.barcodeView.pause()
        gpsHelper.stopLocationUpdates()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}