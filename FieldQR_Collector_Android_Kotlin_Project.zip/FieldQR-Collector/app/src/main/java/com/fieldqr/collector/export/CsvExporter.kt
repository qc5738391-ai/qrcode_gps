package com.fieldqr.collector.export

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.fieldqr.collector.data.QrRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CSV 导出工具类
 * 规范：
 * 1. 导出位置：系统 Download 文件夹
 * 2. 文件编码：UTF-8 带 BOM (0xEF, 0xBB, 0xBF)，确保中国大陆版 Excel 打开无任何乱码
 * 3. 表头：记录时间,二维码内容,纬度,经度,海拔
 */
object CsvExporter {

    // CSV 转义处理：处理包含逗号、双引号、换行符的字段
    private fun escapeCsvField(field: String): String {
        return if (field.contains(",") || field.contains(""") || field.contains("
") || field.contains("")) {
            """ + field.replace(""", """") + """
        } else {
            field
        }
    }

    suspend fun exportToDownload(context: Context, records: List<QrRecord>): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "FieldQR_Records_${timeStamp}.csv"

                val outputStream: OutputStream
                val targetPathDisplay: String

                // Android 10 (API 29) 及以上使用 MediaStore 写入公共 Download 目录
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val resolver = context.contentResolver
                    val uri: Uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        ?: return@withContext Result.failure(Exception("无法创建 Download 目录下的文件"))
                    outputStream = resolver.openOutputStream(uri)
                        ?: return@withContext Result.failure(Exception("无法打开输出流"))
                    targetPathDisplay = "Download/$fileName"
                } else {
                    // Android 9 及以下使用标准文件系统写入 Download
                    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadDir.exists()) {
                        downloadDir.mkdirs()
                    }
                    val targetFile = File(downloadDir, fileName)
                    outputStream = FileOutputStream(targetFile)
                    targetPathDisplay = targetFile.absolutePath
                }

                outputStream.use { stream ->
                    // 1. 写入 UTF-8 BOM 头 (EF BB BF)，解决 Excel 打开中文乱码核心问题
                    val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
                    stream.write(bom)

                    // 2. 写入标准表头：记录时间,二维码内容,纬度,经度,海拔
                    val header = "记录时间,二维码内容,纬度,经度,海拔
"
                    stream.write(header.toByteArray(Charsets.UTF_8))

                    // 3. 逐行写入记录
                    for (record in records) {
                        val line = StringBuilder()
                            .append(escapeCsvField(record.recordTime)).append(",")
                            .append(escapeCsvField(record.qrText)).append(",")
                            .append(record.lat).append(",")
                            .append(record.lon).append(",")
                            .append(record.altitude)
                            .append("
")
                            .toString()
                        stream.write(line.toByteArray(Charsets.UTF_8))
                    }
                    stream.flush()
                }

                Result.success(targetPathDisplay)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
