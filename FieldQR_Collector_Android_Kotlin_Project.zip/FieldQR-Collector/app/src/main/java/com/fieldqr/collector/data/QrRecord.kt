package com.fieldqr.collector.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 采集点位数据实体类
 * 对应 SQLite/Room 本地数据库表 'qr_records'
 */
@Entity(tableName = "qr_records")
data class QrRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val qrText: String,      // 二维码内容
    val lat: Double,         // 纬度 (高精度GPS)
    val lon: Double,         // 经度 (高精度GPS)
    val altitude: Double,    // 海拔高度 (米)
    val recordTime: String   // 记录时间 (UTC ISO格式或格式化字符串)
)
