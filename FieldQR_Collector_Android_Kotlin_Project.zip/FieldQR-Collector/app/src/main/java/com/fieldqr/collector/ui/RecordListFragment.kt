package com.fieldqr.collector.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.fieldqr.collector.data.AppDatabase
import com.fieldqr.collector.data.QrRecord
import com.fieldqr.collector.databinding.FragmentRecordsBinding
import com.fieldqr.collector.export.CsvExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 记录列表 Fragment
 * 功能：
 * 1. 展示全部采集点位列表
 * 2. 单条删除与一键清空（均带确认二次弹窗）
 * 3. 一键导出全部点位为 CSV 至系统 Download 目录 (带 UTF-8 BOM，Excel 中文不乱码)
 */
class RecordListFragment : Fragment() {

    private var _binding: FragmentRecordsBinding? = null
    private val binding get() = _binding!!

    private val db by lazy { AppDatabase.getDatabase(requireContext()) }
    private lateinit var adapter: RecordAdapter

    private var currentList: List<QrRecord> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecordsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initRecyclerView()
        observeRecords()
        initActions()
    }

    private fun initRecyclerView() {
        adapter = RecordAdapter(
            onDeleteClick = { record ->
                confirmDeleteSingle(record)
            }
        )
        binding.rvRecords.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRecords.adapter = adapter
    }

    private fun observeRecords() {
        // 使用 Flow 实时观察 Room 数据库更新
        viewLifecycleOwner.lifecycleScope.launch {
            db.qrRecordDao().getAllRecordsFlow().collect { records ->
                currentList = records
                adapter.submitList(records)
                binding.tvTotalCount.text = "总计点位: ${records.size}"

                if (records.isEmpty()) {
                    binding.tvEmpty.visibility = View.VISIBLE
                    binding.rvRecords.visibility = View.GONE
                } else {
                    binding.tvEmpty.visibility = View.GONE
                    binding.rvRecords.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun initActions() {
        // 1. 导出 CSV 按钮
        binding.btnExportCsv.setOnClickListener {
            if (currentList.isEmpty()) {
                Toast.makeText(requireContext(), "当前没有可导出的采集记录", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                binding.btnExportCsv.isEnabled = false
                val result = CsvExporter.exportToDownload(requireContext(), currentList)
                binding.btnExportCsv.isEnabled = true

                result.onSuccess { path ->
                    AlertDialog.Builder(requireContext())
                        .setTitle("✅ CSV导出成功")
                        .setMessage("文件已保存至手机公共存储：\n\n$path\n\n编码格式：UTF-8带BOM，可在Excel中直接打开查看。")
                        .setPositiveButton("确定", null)
                        .show()
                }.onFailure { error ->
                    Toast.makeText(requireContext(), "导出失败: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }

        // 2. 一键清空全部按钮
        binding.btnClearAll.setOnClickListener {
            if (currentList.isEmpty()) {
                Toast.makeText(requireContext(), "记录已为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            AlertDialog.Builder(requireContext())
                .setTitle("⚠️ 确认清空全部记录")
                .setMessage("确定要删除本地保存的所有 ${currentList.size} 条点位记录吗？此操作不可逆！")
                .setPositiveButton("确认清空") { _, _ ->
                    viewLifecycleOwner.lifecycleScope.launch {
                        withContext(Dispatchers.IO) {
                            db.qrRecordDao().deleteAll()
                        }
                        Toast.makeText(requireContext(), "已清空全部点位记录", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }

    private fun confirmDeleteSingle(record: QrRecord) {
        AlertDialog.Builder(requireContext())
            .setTitle("删除点位记录")
            .setMessage("确定删除点位 #${record.id}？\n内容: ${record.qrText}")
            .setPositiveButton("删除") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        db.qrRecordDao().deleteById(record.id)
                    }
                    Toast.makeText(requireContext(), "记录已删除", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
