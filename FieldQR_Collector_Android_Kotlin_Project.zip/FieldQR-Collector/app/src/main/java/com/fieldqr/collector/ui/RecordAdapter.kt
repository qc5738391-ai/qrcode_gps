package com.fieldqr.collector.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fieldqr.collector.data.QrRecord
import com.fieldqr.collector.databinding.ItemRecordBinding

/**
 * 记录列表 Adapter (使用 ListAdapter 高性能差分刷新)
 */
class RecordAdapter(
    private val onDeleteClick: (QrRecord) -> Unit
) : ListAdapter<QrRecord, RecordAdapter.RecordViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecordViewHolder {
        val binding = ItemRecordBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecordViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class RecordViewHolder(private val binding: ItemRecordBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(record: QrRecord) {
            binding.tvId.text = "#${record.id}"
            binding.tvRecordTime.text = record.recordTime
            binding.tvQrContent.text = "QR: ${record.qrText}"
            binding.tvCoordinates.text = "纬度: ${"%.6f".format(record.lat)}  经度: ${"%.6f".format(record.lon)}"
            binding.tvAltitude.text = "海拔: ${"%.1f".format(record.altitude)}m"

            binding.btnDelete.setOnClickListener {
                onDeleteClick(record)
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<QrRecord>() {
            override fun areItemsTheSame(oldItem: QrRecord, newItem: QrRecord): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: QrRecord, newItem: QrRecord): Boolean {
                return oldItem == newItem
            }
        }
    }
}
