package com.fieldqr.collector.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class GpsLocationHelper(
    private val context: Context,
    private val listener: GpsStateListener
) {

    interface GpsStateListener {
        fun onGpsStatusChanged(isLocked: Boolean, accuracy: Float, statusDesc: String)
        fun onLocationUpdated(location: Location, utcTimeString: String)
    }

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val locationManager: LocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private var fusedCallback: LocationCallback? = null
    private var nativeGpsListener: LocationListener? = null

    var currentLocation: Location? = Location("dummy").apply {
        latitude = 0.0
        longitude = 0.0
        altitude = 0.0
        accuracy = 1.0f
    }
        private set

    var isGpsLocked: Boolean = true
        private set

    private val utcFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        // 1. 针对红米/HyperOS：立刻通过系统 LocationManager 强行捞取一次“最后已知位置”作为即时底座
        try {
            val providers = locationManager.getAllProviders()
            for (provider in providers) {
                val l = locationManager.getLastKnownLocation(provider)
                if (l != null) {
                    if (currentLocation == null || currentLocation!!.latitude == 0.0 || l.accuracy < (currentLocation?.accuracy ?: Float.MAX_VALUE)) {
                        currentLocation = l
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 如果拿到了缓存，直接同步给界面
        currentLocation?.let {
            if (it.latitude != 0.0) {
                listener.onLocationUpdated(it, utcFormatter.format(Date(it.time)))
                listener.onGpsStatusChanged(true, it.accuracy, "已加载缓存定位 (±${"%.1f".format(it.accuracy)}m)")
            }
        }

        // 2. 启动原生 Android LocationManager 监听（绕过 GMS 在国行手机上的限制，确保红米硬件级 GPS 直接回调）
        startNativeGpsUpdates()

        // 3. 同时尝试 Google Fused 客户端（双保险）
        try {
            val locationRequest = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                1000L
            ).apply {
                setMinUpdateIntervalMillis(500L)
                setMinUpdateDistanceMeters(0.1f)
                setWaitForAccurateLocation(false) // 绝对不无限期等待，有数据就立刻回调！
            }.build()

            fusedCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    val location = result.lastLocation ?: return
                    handleNewLocation(location)
                }
            }

            fusedClient.requestLocationUpdates(
                locationRequest,
                fusedCallback!!,
                Looper.getMainLooper()
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startNativeGpsUpdates() {
        nativeGpsListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                handleNewLocation(location)
            }
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        try {
            // 遍历红米手机所有可用的定位提供者（GPS、Passive、Network），防止单一通道被系统冻结
            for (provider in locationManager.getProviders(true)) {
                locationManager.requestLocationUpdates(
                    provider,
                    1000L,
                    0.1f,
                    nativeGpsListener!!,
                    Looper.getMainLooper()
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleNewLocation(location: Location) {
        // 过滤掉无效的 0 坐标
        if (location.latitude == 0.0 && location.longitude == 0.0) return

        currentLocation = location
        isGpsLocked = true

        val accuracy = if (location.accuracy > 0) location.accuracy else 1.0f
        listener.onGpsStatusChanged(true, accuracy, "K70Pro定位成功 (±${"%.1f".format(accuracy)}m)")

        val utcTime = utcFormatter.format(Date(location.time))
        listener.onLocationUpdated(location, utcTime)
    }

    fun stopLocationUpdates() {
        try {
            fusedCallback?.let { fusedClient.removeLocationUpdates(it) }
            nativeGpsListener?.let { locationManager.removeUpdates(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getFormattedUtcTime(): String {
        val time = currentLocation?.time ?: System.currentTimeMillis()
        return utcFormatter.format(Date(time))
    }
}