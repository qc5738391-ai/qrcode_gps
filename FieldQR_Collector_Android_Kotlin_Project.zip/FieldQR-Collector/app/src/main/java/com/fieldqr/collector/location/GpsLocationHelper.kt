package com.fieldqr.collector.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 高精度GPS定位管理类
 * 严格限制仅使用 GPS 卫星高精度定位，禁用粗略基站/WiFi定位
 */
class GpsLocationHelper(
    private val context: Context,
    private val listener: GpsStateListener
) {

    interface GpsStateListener {
        fun onGpsStatusChanged(isLocked: Boolean, accuracy: Float, statusDesc: String)
        fun onLocationUpdated(location: Location, utcTimeString: String)
    }

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val locationManager: LocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private var fusedCallback: LocationCallback? = null
    private var nativeGpsListener: LocationListener? = null

    // 当前最新定位
    var currentLocation: Location? = null
        private set

    // GPS 是否锁定（精度在 25 米以内视为有效锁定）
    var isGpsLocked: Boolean = false
        private set

    // UTC 时间格式化工具
    private val utcFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        // 1. 检查 GPS 硬件开关
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            isGpsLocked = false
            listener.onGpsStatusChanged(false, 0f, "GPS硬件未启用，请在手机系统设置中打开高精度定位")
            return
        }

        listener.onGpsStatusChanged(false, 0f, "GPS搜星中 (请移步开阔室外)")

        // 2. FusedLocationProvider 严格配置 PRIORITY_HIGH_ACCURACY
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, // 强制高精度GPS
            1000L // 1秒间隔
        ).apply {
            setMinUpdateIntervalMillis(500L)
            setMinUpdateDistanceMeters(0.5f)
            setWaitForAccurateLocation(true) // 等待高精度定位结果
        }.build()

        fusedCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                handleNewLocation(location)
            }
        }

        try {
            fusedClient.requestLocationUpdates(
                locationRequest,
                fusedCallback!!,
                Looper.getMainLooper()
            )
        } catch (e: Exception) {
            // 若设备缺失Google Play服务，降级使用原生 Android GPS Provider
            startNativeGpsUpdates()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startNativeGpsUpdates() {
        nativeGpsListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                handleNewLocation(location)
            }
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {
                isGpsLocked = false
                listener.onGpsStatusChanged(false, 0f, "GPS已关闭")
            }
        }

        // 仅注册 GPS_PROVIDER，明确忽略 NETWORK_PROVIDER
        locationManager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            1000L,
            0.5f,
            nativeGpsListener!!,
            Looper.getMainLooper()
        )
    }

    private fun handleNewLocation(location: Location) {
        currentLocation = location
        val accuracy = location.accuracy

        // 判定准则：精度 <= 25米 视为野外有效锁定；若大于25米，提示仍处于搜星改善中
        if (accuracy > 0 && accuracy <= 25.0f) {
            isGpsLocked = true
            listener.onGpsStatusChanged(true, accuracy, "GPS已锁定 (±${"%.1f".format(accuracy)}m)")
        } else {
            isGpsLocked = false
            listener.onGpsStatusChanged(false, accuracy, "搜星中 (当前精度 ±${"%.1f".format(accuracy)}m，未达到锁定要求)")
        }

        val utcTime = utcFormatter.format(Date(location.time))
        listener.onLocationUpdated(location, utcTime)
    }

    fun stopLocationUpdates() {
        fusedCallback?.let { fusedClient.removeLocationUpdates(it) }
        nativeGpsListener?.let { locationManager.removeUpdates(it) }
    }

    fun getFormattedUtcTime(): String {
        val time = currentLocation?.time ?: System.currentTimeMillis()
        return utcFormatter.format(Date(time))
    }
}
