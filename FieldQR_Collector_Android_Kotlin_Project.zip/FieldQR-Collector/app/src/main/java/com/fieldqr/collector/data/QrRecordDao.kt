package com.fieldqr.collector.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * 点位数据访问对象 (DAO)
 * 支持协程与 Flow 响应式更新
 */
@Dao
interface QrRecordDao {

    // 插入新记录
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: QrRecord): Long

    // 检查是否存在相同二维码（防重复逻辑）
    @Query("SELECT COUNT(*) FROM qr_records WHERE qrText = :qrText")
    suspend fun countByQrText(qrText: String): Int

    // 获取全部记录，按时间倒序排列
    @Query("SELECT * FROM qr_records ORDER BY id DESC")
    fun getAllRecordsFlow(): Flow<List<QrRecord>>

    // 一次性获取全部记录（用于CSV导出）
    @Query("SELECT * FROM qr_records ORDER BY id ASC")
    suspend fun getAllRecordsList(): List<QrRecord>

    // 单条删除
    @Query("DELETE FROM qr_records WHERE id = :recordId")
    suspend fun deleteById(recordId: Long): Int

    // 一键清空全部记录
    @Query("DELETE FROM qr_records")
    suspend fun deleteAll(): Int

    // 获取记录总数
    @Query("SELECT COUNT(*) FROM qr_records")
    suspend fun getCount(): Int
}
